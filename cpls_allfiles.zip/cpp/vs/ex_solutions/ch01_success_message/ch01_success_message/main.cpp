#include <iostream>
using namespace std;

int main() {
	cout << "Success!" << endl << endl;
    return 0;
}