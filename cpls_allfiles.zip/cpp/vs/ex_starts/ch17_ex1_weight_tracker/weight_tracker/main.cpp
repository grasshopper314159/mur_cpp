#include <iostream>
#include <string>
#include <algorithm>
#include <numeric>

using namespace std;

int main()
{
	const int num_months = 12;
	string months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

	cout << "Welcome to the Weight Tracker program!\n\n"
		 << "Please enter your weight at the beginning of each month:\n";

}
